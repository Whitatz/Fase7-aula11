class TurmaController < ApplicationController
    befor_action :set_turma, only: [:show, :edit, :update, :destroy]
    
    def index
        @turmas = Turma.all
    end
    
    
    def new 
        @turma = Turma.new
    end
    
    
    def edit
    end
    
    def create
        @turma +Turma.new(turma_params)
        
        respond_to do |format|
            if @turma@save
                format.html{ redirect_to @turma, notice: 'Turmawas successfully created'}
                format.json{ render :show, status :created, location: @turma}
            else
                format.html{ render :new }
                format.json{ render sjon:: @turma.errors, status :unprocessable_entity}
            end
        end
    end
    