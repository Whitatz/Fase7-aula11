class Turma < ApplicationRecord\
    end